
export enum ModelType {
    CBOW = 'CBOW',
    SKIP_GRAM = 'Skip-gram'
}

export interface CbowData {
    targetWord: string;
    contextWords: string[];
}

export interface SkipGramData {
    inputWord: string;
    predictedContextWords: string[];
}

export type VisualizationData = CbowData | SkipGramData;
