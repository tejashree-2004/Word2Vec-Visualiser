
import { GoogleGenAI, Type } from "@google/genai";
import { ModelType, VisualizationData, CbowData, SkipGramData } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const cbowSchema = {
  type: Type.OBJECT,
  properties: {
    targetWord: {
      type: Type.STRING,
      description: 'The central target word predicted from the context.',
    },
    contextWords: {
      type: Type.ARRAY,
      items: {
        type: Type.STRING,
      },
      description: 'The surrounding words used as context. Should be 2 to 4 words.',
    },
  },
  required: ['targetWord', 'contextWords'],
};

const skipGramSchema = {
    type: Type.OBJECT,
    properties: {
        inputWord: {
            type: Type.STRING,
            description: 'The central input word used to predict the context.',
        },
        predictedContextWords: {
            type: Type.ARRAY,
            items: {
                type: Type.STRING,
            },
            description: 'The surrounding words predicted from the input word. Should be 2 to 4 words.',
        },
    },
    required: ['inputWord', 'predictedContextWords'],
};

const getPromptAndSchema = (text: string, model: ModelType) => {
    if (model === ModelType.CBOW) {
        return {
            prompt: `You are an expert in NLP and Word2Vec. Analyze the following sentence for the CBOW model: "${text}". Identify a single, central target word and its immediate surrounding context words (window size of 1 or 2, resulting in 2 to 4 context words). Return a JSON object matching the provided schema. Choose a word that has context on both sides if possible.`,
            schema: cbowSchema,
        };
    } else {
        return {
            prompt: `You are an expert in NLP and Word2Vec. Analyze the following sentence for the Skip-gram model: "${text}". Identify a single, central input word and the context words it would predict (window size of 1 or 2, resulting in 2 to 4 context words). Return a JSON object matching the provided schema. Choose a word that has context on both sides if possible.`,
            schema: skipGramSchema,
        };
    }
};

export const generateVisualizationData = async (text: string, model: ModelType): Promise<VisualizationData> => {
    const { prompt, schema } = getPromptAndSchema(text, model);

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            responseSchema: schema,
        },
    });

    const jsonText = response.text.trim();
    try {
        const parsedJson = JSON.parse(jsonText);
        if (model === ModelType.CBOW) {
            return parsedJson as CbowData;
        } else {
            return parsedJson as SkipGramData;
        }
    } catch (e) {
        console.error("Failed to parse JSON from Gemini:", jsonText);
        throw new Error("Invalid JSON response from the model.");
    }
};
