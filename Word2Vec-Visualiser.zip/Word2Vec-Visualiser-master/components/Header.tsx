
import React from 'react';
import { BrainCircuit } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="w-full max-w-7xl mb-8 text-center">
      <div className="flex items-center justify-center gap-4 mb-2">
        <BrainCircuit className="w-12 h-12 text-brand-primary" />
        <h1 className="text-4xl sm:text-5xl font-extrabold text-text-primary tracking-tight">
          Word2Vec Visualizer
        </h1>
      </div>
      <p className="text-text-secondary text-lg">
        An interactive playground to understand CBOW & Skip-gram models.
      </p>
    </header>
  );
};

export default Header;
