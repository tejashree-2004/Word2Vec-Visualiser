
import React from 'react';
import { CbowData } from '../types';
import WordBox from './common/WordBox';
import { ArrowRight } from 'lucide-react';

const CbowVisualization: React.FC<{ data: CbowData }> = ({ data }) => {
  return (
    <div className="w-full flex flex-col items-center justify-center p-4 animate-fade-in">
        <h2 className="text-2xl font-bold text-brand-primary mb-2">CBOW (Continuous Bag of Words)</h2>
        <p className="text-text-secondary mb-10 text-center max-w-2xl">The model takes context words to predict a target word. It asks, "Given these words, what word is missing?"</p>

        <div className="w-full flex items-center justify-around flex-wrap gap-8">
            {/* Context Words */}
            <div className="flex flex-col items-center gap-4 animate-fade-in" style={{animationDelay: '0.2s'}}>
                <h3 className="text-lg font-semibold text-text-secondary">Context Words</h3>
                <div className="flex flex-wrap justify-center gap-4">
                    {(data.contextWords || []).map((word, index) => (
                        <WordBox key={index} word={word} />
                    ))}
                </div>
            </div>

            {/* Arrow and Projection Layer */}
            <div className="flex flex-col items-center gap-2 animate-fade-in" style={{animationDelay: '0.5s'}}>
                 <ArrowRight className="w-12 h-12 sm:w-16 sm:h-16 text-text-secondary" />
                 <div className="text-center text-sm text-text-secondary mt-1">
                     <p className="font-bold">Projection</p>
                     <p>(Sum/Average)</p>
                 </div>
            </div>

            {/* Target Word */}
            <div className="flex flex-col items-center gap-4 animate-fade-in" style={{animationDelay: '0.8s'}}>
                <h3 className="text-lg font-semibold text-text-secondary">Predicted Target</h3>
                <WordBox word={data.targetWord} highlight />
            </div>
        </div>
    </div>
  );
};

export default CbowVisualization;
