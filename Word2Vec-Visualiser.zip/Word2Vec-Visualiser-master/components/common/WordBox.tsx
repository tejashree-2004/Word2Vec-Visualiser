
import React from 'react';

interface WordBoxProps {
  word: string;
  highlight?: boolean;
}

const WordBox: React.FC<WordBoxProps> = ({ word, highlight = false }) => {
  const baseClasses = "px-6 py-3 rounded-lg text-lg font-medium shadow-md transition-all duration-300 transform hover:-translate-y-1";
  const highlightClasses = "bg-brand-primary text-white scale-110 shadow-xl";
  const defaultClasses = "bg-base-300 text-text-primary";

  return (
    <div className={`${baseClasses} ${highlight ? highlightClasses : defaultClasses}`}>
      {word}
    </div>
  );
};

export default WordBox;
