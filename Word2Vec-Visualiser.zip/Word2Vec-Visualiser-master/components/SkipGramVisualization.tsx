
import React from 'react';
import { SkipGramData } from '../types';
import WordBox from './common/WordBox';
import { ArrowRight } from 'lucide-react';

const SkipGramVisualization: React.FC<{ data: SkipGramData }> = ({ data }) => {
  return (
    <div className="w-full flex flex-col items-center justify-center p-4 animate-fade-in">
      <h2 className="text-2xl font-bold text-brand-primary mb-2">Skip-gram</h2>
      <p className="text-text-secondary mb-10 text-center max-w-2xl">The model takes a single input word to predict its surrounding context words. It asks, "Given this word, what are its neighbors?"</p>
      
      <div className="w-full flex items-center justify-around flex-wrap gap-8">
        {/* Input Word */}
        <div className="flex flex-col items-center gap-4 animate-fade-in" style={{animationDelay: '0.2s'}}>
          <h3 className="text-lg font-semibold text-text-secondary">Input Word</h3>
          <WordBox word={data.inputWord} highlight />
        </div>
        
        {/* Arrow */}
        <div className="flex flex-col items-center gap-2 animate-fade-in" style={{animationDelay: '0.5s'}}>
            <ArrowRight className="w-12 h-12 sm:w-16 sm:h-16 text-text-secondary" />
             <div className="text-center text-sm text-text-secondary mt-1">
                 <p className="font-bold">Projection</p>
             </div>
        </div>
        
        {/* Predicted Context Words */}
        <div className="flex flex-col items-center gap-4 animate-fade-in" style={{animationDelay: '0.8s'}}>
          <h3 className="text-lg font-semibold text-text-secondary">Predicted Context</h3>
          <div className="flex flex-wrap justify-center gap-4">
            {(data.predictedContextWords || []).map((word, index) => (
              <WordBox key={index} word={word} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SkipGramVisualization;
